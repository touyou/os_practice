/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int v_val;

int v_fun(int arg)
{
	return arg + v_val;
}
