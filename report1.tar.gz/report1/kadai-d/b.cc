/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int b_val;

int b_fun(int arg)
{
	return arg + b_val;
}
