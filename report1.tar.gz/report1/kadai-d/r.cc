/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int r_val;

int r_fun(int arg)
{
	return arg + r_val;
}
