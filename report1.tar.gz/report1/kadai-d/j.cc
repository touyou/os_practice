/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int j_val;

int j_fun(int arg)
{
	return arg + j_val;
}
