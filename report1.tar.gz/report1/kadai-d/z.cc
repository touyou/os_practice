/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int z_val;

int z_fun(int arg)
{
	return arg + z_val;
}
