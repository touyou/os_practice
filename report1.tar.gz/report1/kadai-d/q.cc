/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int q_val;

int q_fun(int arg)
{
	return arg + q_val;
}
