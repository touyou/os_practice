/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int i_val;

int i_fun(int arg)
{
	return arg + i_val;
}
