/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int s_val;

int s_fun(int arg)
{
	return arg + s_val;
}
