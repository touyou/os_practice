/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int n_val;

int n_fun(int arg)
{
	return arg + n_val;
}
