/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int g_val;

int g_fun(int arg)
{
	return arg + g_val;
}
