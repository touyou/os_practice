/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int m_val;

int m_fun(int arg)
{
	return arg + m_val;
}
