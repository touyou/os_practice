/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int y_val;

int y_fun(int arg)
{
	return arg + y_val;
}
