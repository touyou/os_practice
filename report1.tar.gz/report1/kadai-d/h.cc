/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int h_val;

int h_fun(int arg)
{
	return arg + h_val;
}
