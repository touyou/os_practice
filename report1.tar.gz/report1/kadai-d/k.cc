/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int k_val;

int k_fun(int arg)
{
	return arg + k_val;
}
