/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int o_val;

int o_fun(int arg)
{
	return arg + o_val;
}
