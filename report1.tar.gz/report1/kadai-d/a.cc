/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int a_val;

int a_fun(int arg)
{
	return arg + a_val;
}
