/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int x_val;

int x_fun(int arg)
{
	return arg + x_val;
}
