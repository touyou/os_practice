/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int u_val;

int u_fun(int arg)
{
	return arg + u_val;
}
