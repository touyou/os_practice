/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int w_val;

int w_fun(int arg)
{
	return arg + w_val;
}
