/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int e_val;

int e_fun(int arg)
{
	return arg + e_val;
}
