/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int p_val;

int p_fun(int arg)
{
	return arg + p_val;
}
