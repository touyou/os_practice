/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int f_val;

int f_fun(int arg)
{
	return arg + f_val;
}
