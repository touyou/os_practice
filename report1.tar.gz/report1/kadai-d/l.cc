/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int l_val;

int l_fun(int arg)
{
	return arg + l_val;
}
