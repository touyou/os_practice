/*
  Author: Fujii Yosuke <touyu1121@is.s.u-tokyo.ac.jp>
 */

int t_val;

int t_fun(int arg)
{
	return arg + t_val;
}
